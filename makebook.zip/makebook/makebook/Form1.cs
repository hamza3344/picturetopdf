﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iText.IO.Image;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;

namespace makebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<string> files = new List<string>();
            bool start = false;
            DialogResult dr = openFileDialog1.ShowDialog();
            if(dr==DialogResult.OK)
            {
                foreach(string file in openFileDialog1.FileNames)
                {
                    files.Add(file);
                    start = true;
                }
            }
            if(start)
            {
                files.Sort();
                PdfWriter writer = new PdfWriter(files[0].Substring(0, files[0].LastIndexOf(@"\")) + @"\book.pdf");
                PdfDocument pdf = new PdfDocument(writer);
                Document document = new Document(pdf, PageSize.A4);
                foreach(string s in files)
                {
                    iText.Layout.Element.Image img = new iText.Layout.Element.Image(ImageDataFactory.Create(s))
                        .SetHorizontalAlignment(iText.Layout.Properties.HorizontalAlignment.CENTER);
                    float width = PageSize.A4.GetWidth() - img.GetImageWidth();
                    document.SetTopMargin(width / 2);
                    document.SetBottomMargin(width / 2);
                    document.Add(img);
                    pdf.AddNewPage();
                }
                document.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Initialize();
        }
        private void Initialize()
        {
            this.openFileDialog1.Filter = "Images (*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*.PNG|"
                + "All files(*.*)|*.*";
            openFileDialog1.Multiselect = true;
            openFileDialog1.Title = "My Book Image";
        }
    }
}
